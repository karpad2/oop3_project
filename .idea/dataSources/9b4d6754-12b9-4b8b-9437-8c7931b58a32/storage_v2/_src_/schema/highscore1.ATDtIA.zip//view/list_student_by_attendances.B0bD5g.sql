create view list_student_by_attendances as
  select `ud`.`subject_id`  AS `subject_id`,
         `ud`.`user_id`     AS `user_id`,
         `ud`.`upload_date` AS `date`,
         `at`.`student_id`  AS `student_id`
  from (`highscore1`.`upload_data` `ud` join `highscore1`.`attendances` `at` on ((`ud`.`weeknumber_upload_id` =
                                                                                  `at`.`weeknumber_upload_id`)))
  group by `ud`.`subject_id`;

