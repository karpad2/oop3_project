create view list_student_by_points as
  select `st`.`student_id` AS `student_id`, sum(`sp`.`point`) AS `points`, concat(`sb`.`badge_id`, ',') AS `badges`
  from ((`highscore1`.`students` `st` join `highscore1`.`students_points` `sp` on ((`st`.`student_id` =
                                                                                    `sp`.`student_id`))) join `highscore1`.`students_badge` `sb` on ((
    `sb`.`student_id` = `st`.`student_id`)))
  group by `st`.`student_id`
  order by sum(`sp`.`point`) desc;

