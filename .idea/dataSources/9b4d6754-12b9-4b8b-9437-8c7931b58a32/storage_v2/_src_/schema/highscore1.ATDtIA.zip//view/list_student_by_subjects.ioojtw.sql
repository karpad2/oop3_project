create view list_student_by_subjects as
  select `ss`.`subject_id` AS `subject_ID`, `ss`.`student_id` AS `student_id`
  from `highscore1`.`students_subject` `ss`
  group by `ss`.`subject_id`;

